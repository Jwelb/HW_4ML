Team Members
==========================================
Joshua Phillips   - phillipsjosh18@students.ecu.edu
Kayleigh Leblanc  - leblanck16@stuents.ecu.edu
Patrick Emery     - emeryp15@students.ecu.edu
Ryan McLean       - mcleanry16@students.ecu.edu

Quick Start
==========================================
run using python 3
need to have scipy, pandas, seaborn, sklearn, numpy, and matplotlib installed
can install with:
sudo pip3 install -r requirements.txt

Which K works the best?
==========================================
K = 4 works the best.

The Best K Accuracy
=========================================
The best K accuracy was K = 10.

for confusion matrix please see matrix.png