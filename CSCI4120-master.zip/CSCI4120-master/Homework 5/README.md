Team member names and email addresses
=======================================================================

Joshua Phillips   - phillipsjosh18@students.ecu.edu
Kayleigh Leblanc  - leblanck16@stuents.ecu.edu
Patrick Emery     - emeryp15@students.ecu.edu
Ryan McLean       - mcleanry16@students.ecu.edu


Parameters Selected
=======================================================================

Linear kernels - C
Radial kernels - C, gamma
Polynomial kernels - C, gamma, degree, coef0


Results
=======================================================================
Linear kernels -
accuracy: 0.9360044518642181
C: 0.008138856569673836

Radial kernels -
accuracy: 0.9721758486366165
C: 2.252669990467555
gamma: 0.0009330000675629047

Polynomial kernels -
accuracy: 0.9649415692821369
C: 0.7492153079302818
gamma: 0.0003286431652391375
degree: 6.0
coef0: 0.8562351535955126
