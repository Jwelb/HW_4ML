Team Members
==========================================
Joshua Phillips   - phillipsjosh18@students.ecu.edu
Kayleigh Leblanc  - leblanck16@stuents.ecu.edu
Patrick Emery     - emeryp15@students.ecu.edu
Ryan McLean       - mcleanry16@students.ecu.edu

Quick Start
==========================================
run using python 3
need to have scipy, pandas, seaborn, sklearn, numpy, and matplotlib installed
can install with:
sudo pip3 install -r requirements.txt

Which K works the best?
==========================================
k=9 seems to work the best (of the values from 1 to 10),
though the results vary slightly with each simulation.

For line chart please see linechart.png