Team member names and email addresses
=======================================================================

Joshua Phillips   - phillipsjosh18@students.ecu.edu
Kayleigh Leblanc  - leblanck16@stuents.ecu.edu
Patrick Emery     - emeryp15@students.ecu.edu
Ryan McLean       - mcleanry16@students.ecu.edu


All three models’ cross validation scores and alpha value (if applied)
=======================================================================
Cross Validation - 			score : .7691752923789884

Lasso - 					score : 0.7694662948678218
							alpha : 0.9911541375888815

Ridge Regression Model -	score : 0.7705762098293304
							alpha : 0.9969599962313797


Which model performs the best
=======================================================================

They all perform about the same, but Ridge regression consistently produces better results.